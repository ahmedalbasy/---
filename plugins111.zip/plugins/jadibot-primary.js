import ws from 'ws';

let handler = async (m, { conn, usedPrefix, args }) => {
if (!args[0]) return m.reply(`⚠️ العلامات في عدد بعض الروبوتات\nمثال: ${usedPrefix}صلاحيات @منشن`);

const users = [...new Set([...global.conns.filter((conn) => conn.user && conn.ws.socket && conn.ws.socket.readyState !== ws.CLOSED).map((conn) => conn)])];
let botJid;
let selectedBot;

if (m.mentionedJid && m.mentionedJid.length > 0) {
botJid = m.mentionedJid[0];
if (botJid === conn.user.jid || global.conn.user.jid) {
selectedBot = conn;
} else {
selectedBot = users.find(conn => conn.user.jid === botJid);
}} 
else {
botJid = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
if (botJid === conn.user.jid) {
selectedBot = conn;
} else {
selectedBot = users.find(conn => conn.user.jid === botJid);
}}

if (!selectedBot) return m.reply("⚠️ لم يتم العثور على أي روبوت متصل بهذا البوت أو الرقم. ارسل *.بوتات* لرؤية الروبوتات المتاحة.");
let chat = global.db.data.chats[m.chat];
chat.primaryBot = botJid; 
conn.sendMessage(m.chat, { text: `✅ البوت @${botJid.split('@')[0]} تم تأسيسه البوت باعتباره الأساسي في هذه المجموعة. لن تستجيب الروبوتات الأخرى هنا.`, mentions: [botJid] }, { quoted: m });
};
handler.help = ['setprimary <@tag>'];
handler.tags = ['jadibot'];
handler.command = ['صلاحيات'];
handler.group = true;
handler.register = true;

export default handler;