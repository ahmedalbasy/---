/*
El codigo de este archivo esta totalmente hecho por:
- ReyEndymion (https://github.com/ReyEndymion)
*/

import fs from "fs"
let handler = async (m, { conn, usedPrefix }, args, command) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let uniqid = `${who.split`@`[0]}`
try {
if(global.conns.push(conn))
await conn.sendMessage(m.chat, {text : usedPrefix + 'serbot' + " " + Buffer.from(fs.readFileSync("./GataJadiBot/" + uniqid + "/creds.json"), "utf-8").toString("base64")}, { quoted: m })
} catch(e) {
await conn.reply(m.chat, `*أنت لست روبوتًا فرعيًا لهذا الروبوت..*

> 👉 لتصبح روبوتًا فرعيًا، استخدم الأمر::
\`${usedPrefix + 'تنصيب'}\`

>⚠️ هل تواجه مشاكل في تسجيل الدخول؟
 *إذا لم تتمكن من الوصول إلى جلستك، فاحذف الجلسة التي تم إنشاؤها من الأجهزة المرتبطة واستخدم الأمر::*
\`${usedPrefix + 'eliminarjb'}\`
بهذه الطريقة، يمكنك طلب جلسة جديدة.`, m)
if (m.fromMe) return
}}
handler.command = /^(codetoken)$/i
handler.private = true
export default handler
