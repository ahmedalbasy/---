/*const {downloadContentFromMessage} = (await import('@whiskeysockets/baileys'));

export async function before(m, {isAdmin, isBotAdmin}) {
  const chat = db.data.chats[m.chat];
  if (/^[.~#/\$,](read)?viewonce/.test(m.text)) return;
  if (!chat.antiviewonce || chat.isBanned) return;
  if (m.mtype == 'viewOnceMessageV2') {
    const msg = m.message.viewOnceMessageV2.message;
    const type = Object.keys(msg)[0];
    const media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video');
    let buffer = Buffer.from([]);
    for await (const chunk of media) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    if (/videoo/.test(type)) {
      return this.sendFile(m.chat, buffer, 'error.mp4', `${msg[type].caption}\n\n*سوري انا بضان 🐦❤️‍🩹*`, m);
    } else if (/imagee/.test(type)) {
      return this.sendFile(m.chat, buffer, 'error.jpg', `${msg[type].caption}\n\n*سوري انا بضان 🐦❤️‍🩹*`, m);
    }
  }
}
........ */
const fs = require("fs");
const path = require("path");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

const handler = async (msg, { conn }) => {
  const rawID = conn.user?.id || "";
  const subbotID = rawID.split(":")[0] + "@s.whatsapp.net";

  const prefixPath = path.resolve("prefixes.json");
  let prefixes = {};
  if (fs.existsSync(prefixPath)) {
    prefixes = JSON.parse(fs.readFileSync(prefixPath, "utf-8"));
  }
  const usedPrefix = prefixes[subbotID] || ".";

  const quotedInfo = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!quotedInfo) {
    return await conn.sendMessage(msg.key.remoteJid, {
      text: "❌ *Error:* Debes responder a un mensaje de *ver una sola vez* (imagen, video o audio) para poder verlo nuevamente."
    }, { quoted: msg });
  }

  let mediaType, mediaMessage;
  if (quotedInfo.imageMessage?.viewOnce) {
    mediaType = "image";
    mediaMessage = quotedInfo.imageMessage;
  } else if (quotedInfo.videoMessage?.viewOnce) {
    mediaType = "video";
    mediaMessage = quotedInfo.videoMessage;
  } else if (quotedInfo.audioMessage?.viewOnce) {
    mediaType = "audio";
    mediaMessage = quotedInfo.audioMessage;
  } else {
    return await conn.sendMessage(msg.key.remoteJid, {
      text: "❌ *Error:* Solo puedes usar este comando en mensajes de *ver una sola vez*."
    }, { quoted: msg });
  }

  await conn.sendMessage(msg.key.remoteJid, {
    react: { text: "⏳", key: msg.key }
  });

  const mediaStream = await new Promise(async (resolve, reject) => {
    try {
      const stream = await downloadContentFromMessage(mediaMessage, mediaType);
      let buffer = Buffer.alloc(0);
      for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
      resolve(buffer);
    } catch {
      reject(null);
    }
  });

  if (!mediaStream || mediaStream.length === 0) {
    return await conn.sendMessage(msg.key.remoteJid, {
      text: "❌ *Error:* No se pudo descargar el archivo. Intenta de nuevo."
    }, { quoted: msg });
  }

  let messageOptions = { mimetype: mediaMessage.mimetype };
  if (mediaType === "image") messageOptions.image = mediaStream;
  if (mediaType === "video") messageOptions.video = mediaStream;
  if (mediaType === "audio") messageOptions.audio = mediaStream;

  await conn.sendMessage(msg.key.remoteJid, messageOptions, { quoted: msg });

  await conn.sendMessage(msg.key.remoteJid, {
    react: { text: "✅", key: msg.key }
  });
};

handler.command = ["ver"];
module.exports = handler;
