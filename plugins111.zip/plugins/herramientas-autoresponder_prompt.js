let handler = async (m, { conn, text, usedPrefix, command, isOwner, isAdmin, isROwner }) => {
if (!(isOwner || isAdmin || isROwner)) {
conn.reply(m.chat, "❌ *لا يُسمح لك بتخصيص الرد الآلي الخاص بالروبوت في هذه الدردشة.*\n\n💡 *اطلب من المسؤول ما إذا كانت هذه الدردشة عبارة عن مجموعة أو من منشئ الروبوت للقيام بذلك نيابةً عنك في هذه الدردشة.*", m)
}
const chatData = global.db.data.chats[m.chat]
if (text) {
if (chatData.sAutorespond) return conn.reply(m.chat, `⚠️ *يوجد حاليًا الموجه التالي قيد الاستخدام*\n\n${chatData.sAutorespond}\n\n💡 *إذا كنت تريد تغيير الامر، استخدم امر الغاء لتلغي الامر القديم..*`, m)

chatData.sAutorespond = text
conn.reply(m.chat, `✅ *التكوين الناجح.*\n\n*لقد قمت بتعيين مطالبة جديدة لهذه الدردشة.*\n💬 من الآن فصاعدا، قم بتنشيط الاستخدام *${usedPrefix}on ردود*, سيستخدم الروبوت اسم المناداة التي قمت بتعيينها.\n\n> *تذكر وضع علامة على رسالة من الروبوت أو الرد عليها حتى يستجيب لك.*`, m)
} else {
if (chatData.sAutorespond) {
chatData.sAutorespond = ''
conn.reply(m.chat, "🗑️ *تم حذف اسن المناداة بنجاح..*", m)
} else {
conn.reply(m.chat, `⚠️ *لا توجد مجموعة موجهة لهذه الدردشة..*\n\n💡 *لتعيين اسم مناداة جديد، استخدم الأمر متبوعًا بنص يصف تعليمات للروبوت..*\n\n*Por مثال:*\n*${usedPrefix + command}* يعمل كطبيب نفسي ويقدم الدعم العاطفي للمستخدمين.`, m)
}}
}

handler.command = /^(مناداه|مناداة|autoresponder)$/i
export default handler
