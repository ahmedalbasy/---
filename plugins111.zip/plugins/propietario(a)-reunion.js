let handler = async(m, { conn, command }) => {

let text = `*🥏 المالك @${m.sender.split`@`[0]} لقد طلبت حضورك بين الموظفين، يرجى الحضور الى مجموعة الموظفين في أقرب وقت ممكن*

*مـــع تــحـيات المـــطور مـــيزو👑 🐱*`
m.reply('*⚠️ إرسال رسالة إلى جميع المالكين*')
for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
                        let data = (await conn.onWhatsApp(jid))[0] || {}
                        if (data.exists)
                        conn.sendPayment(data.jid, '10000', text, m)
                        
                           // conn.reply(data.jid, text, m, { mentions: [m.sender] })
                    }

}
handler.tags = ['owner']
handler.command = handler.help =['اجتماع']
handler.rowner = true

export default handler
