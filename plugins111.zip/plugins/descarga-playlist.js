import yts from 'yt-search';
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
if (!text) return conn.reply(m.chat, `${lenguajeGB['smsAvisoMG']()}*أدخل اسم او رابط مقطع فيديو الذي تريد تنزيله 🤖🖲*\n\n*انتظر جاري تنزيل الفيديو او الاغنية الذي طلبتها⌛...*`, fkontak,  m)
try {
    let result = await yts(text);
    let ytres = result.videos;
  let teskd = `*الفيديو الذي تريد تنزيله 🖲 *${text}*`
    
let listSections = [];
for (let index in ytres) {
        let v = ytres[index];
        listSections.push({
         title: `${htki} *تم تطوير البوت بواسطه ميزو👑* ${htka}`,
            rows: [
                {
                    header: 'صوت',
                    title: "",
                    description: `${v.title} | ${v.timestamp}\n`, 
                    id: `${usedPrefix}ytmp3 ${v.url}`
                },
                {
                    header: "فيديو",
                    title: "" ,
                    description: `${v.title} | ${v.timestamp}\n`, 
                    id: `${usedPrefix}ytmp4 ${v.url}`
                }, 
              {
                    header: "ملف صوتي",
                    title: "" ,
                    description: `${v.title} | ${v.timestamp}\n`, 
                    id: `${usedPrefix}ytmp3doc ${v.url}`
                }, 
                {
                    header: "ملف فيديو",
                    title: "" ,
                    description: `${v.title} | ${v.timestamp}\n`, 
                    id: `${usedPrefix}ytmp4doc ${v.url}`
                }
            ]
        });
    }
await conn.sendList(m.chat, `${htki} *بوت ميزو👑* ${htka}\n`, `\n*الفيديو الذي تريد تنزيله🖲* ${text}`, `ا*اختر من القائمة 🤖`, listSections, fkontak);
} catch (e) {
await conn.sendButton(m.chat, `\n${wm}`, lenguajeGB['smsMalError3']() + '#report ' + usedPrefix + command, null, [[lenguajeGB.smsMensError1(), `#reporte ${lenguajeGB['smsMensError2']()} *${usedPrefix + command}*`]], null, null, m)
console.log(e) 
}}
handler.help = ['playlist', 'تنزيل']
handler.tags = ['dl']
handler.command = /^تنزيل|ytbuscar|yts(earch)?$/i
handler.limit = 1
handler.level = 3
export default handler
