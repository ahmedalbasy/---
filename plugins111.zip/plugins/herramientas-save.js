// Código elaborado por: https://github.com/elrebelde21

import uploadFile from '../lib/uploadFile.js';

let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `⚠️ *الاستخدام:*\n${usedPrefix + command} وكتب اسم الامر كي يحفظ وسائط صور فيد... الخ \n${usedPrefix + command} الامر - الرد \n\n مثال. احفظ كيفك - الحمدالله`;

let content = {}, keyword, caption; 
const q = m.quoted;
const splitText = text.split(/[-|,]/).map(s => s.trim());
const hasSeparator = splitText.length > 1;

if (q) {
const isMedia = ['image', 'video', 'sticker', 'audio'].some(type => q.mimetype?.startsWith(type));
keyword = hasSeparator ? splitText[1] : text;
caption = hasSeparator ? splitText[0] : q.caption || '';

if (isMedia) {
const buffer = await q.download();
content = { type: (q.mtype === 'stickerMessage' || (q.mimetype === 'image/webp' && typeof q.isAnimated !== 'undefined')) ? 'sticker' : 
q.mimetype.startsWith('image') ? 'image' : 
q.mimetype.startsWith('video') ? 'video' : 
q.mimetype.startsWith('audio') ? 'audio' : 'sticker',
data: buffer.toString('base64'),
caption: caption,
isAnimated: q.mimetype === 'image/webp' ? q.isAnimated || false : false
};      
} else if (q.text) {
content = { type: 'text',
value: hasSeparator ? splitText[0] : q.text,
mentions: q.mentionedJid || []
};
keyword = hasSeparator ? splitText[1] : text;
}
} else {
if (!hasSeparator) throw `⚠️ تنسيق غير صحيح: ${usedPrefix}حفظ الامر - الرد`;
content = { type: 'text',
value: splitText[0],
mentions: []
};
keyword = splitText[1];
}

if (!content.type) throw '⚠️ نوع المحتوى غير معتمد';
if (!global.db.data.chats[m.chat].savedContent) global.db.data.chats[m.chat].savedContent = {};
  global.db.data.chats[m.chat].savedContent[keyword.toLowerCase()] = content;

await m.reply(`✅ *${keyword}* تم حفظه في الدردشة.`);
await m.react("✅");
};
handler.command = /^(guardar|احفظ)$/i;
handler.group = true;
export default handler;