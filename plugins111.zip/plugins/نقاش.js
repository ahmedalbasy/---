let handler = async (m, { conn, command, text }) => {
let love = `
*☬ ⊱⊶✤⊷⊰ •〔🕸〕• ⊱⊶✤⊷⊰ ☬*
       *☬ســـؤال نـقــ♨️ـاشــي☬*
*☬ ⊱⊶✤⊷⊰ •〔🕸〕• ⊱⊶✤⊷⊰ ☬*

~*☬ الانمـــي :*~ *『』*

~*☬ النقـــاش 🗣 :*~ *『』*

~*☬ المكـــافأة 💰 :*~ *『』*

~*☬ المســـؤول 🎙:*~ *『』*
*☬ ⊱⊶✤⊷⊰ •〔🕸〕• ⊱⊶✤⊷⊰ ☬*
*~𝔹𝕆𝕋⏤͟͟͞ 𝔸-𝕊:~* 
`.trim()
m.reply(love, null, { mentions: conn.parseMention(love) })}
handler.help = ['estupidez']
handler.tags = ['fun']
handler.command = /^(النقاش|نقاش)$/i
export default handler
