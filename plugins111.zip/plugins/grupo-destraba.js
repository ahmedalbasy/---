let handler = async (m, { conn }) => {
m.reply(global.destraba)
m.reply(global.destraba)
}
handler.command = /^(مضاد|deztraba|clear)$/i
export default handler
