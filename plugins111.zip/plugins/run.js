function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms % 3600000 / 60000);
  let s = Math.floor(ms % 60000 / 1000);
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

const handler = async (m, {conn, usedPrefix, usedPrefix: _p, __dirname, text, isPrems}) => {
  let d = new Date(new Date + 3600000);
  let locale = 'ar';
  let week = d.toLocaleDateString(locale, { weekday: 'long' });
  let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender)
  let { money, joincount } = global.db.data.users[m.sender];
  let { exp, limit, level, role } = global.db.data.users[m.sender];
  let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length;
  let more = String.fromCharCode(8206);
  let readMore = more.repeat(850);
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
  let taguser = '@' + m.sender.split("@s.whatsapp.net")[0];
await conn.sendMessage(m.chat, { react: { text: '💿', key: m.key } })
const PLUTO = 'https://qu.ax/iWdKk.jpg'
const mentionId = m.key.participant || m.key.remoteJid;

conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage: { header: { title: `gataVidMenu`}, body: { text: `*مــرحــبــا بــك/ي* @${mentionId.split('@')[0]}
┏━━🤖 _مـعلـومـات البـوت:_🤖━━┓
┃✨  *اسـم المطور:* مــــــيزو👑
┣➤ المطور سجاد💻
┣➤ الادمن الفخم عاهد😎
┃💻 *المـنصـة:* WhatsApp💀 
┃*🐉✬⃝حط نقطة قبل اي امر : ⌊ . ⌉
┃*🐉✬⃝╿الـبــوت للجميع*
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━┓
┃ *< إعدادات البوت >*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣➤ اذا رسايل في الانتظار
┣ ඬ⃟ ⚡ *.صلح*
┗━━━━━━━━━━━━━━━━┛
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
*☰ اوامر البـوت↯°*
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥🌐│الـجـروب│🌐⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟🚫❯ .انذار
│✮ ⃟⭕❯ .رفع-انذار
│✮ ⃟🚷❯ .الانذارات
│✮ ⃟➕❯ .دعوه
│✮ ⃟📧❯ .منشن
│✮ ⃟👽❯ .مخفي
│✮ ⃟👨🏽‍✈️❯ .المشرفين
│✮ ⃟🛋️❯ .جروب
│✮ ⃟🚸❯ .طرد
│✮ ⃟♻️❯ .رستر
│✮ ⃟🗑️❯ .حذف
│✮ ⃟🤿❯ .واتس
│✮ ⃟🪀❯ .لينك
│✮ ⃟📰❯ .جروبي
│✮ ⃟📇❯ .فحص
│✮ ⃟📢❯ .تغيرالترحيب 
│✮ ⃟☠️❯ .تغيرالوداع
│✮ ⃟↗️❯ .رفع 
│✮ ⃟↘️❯ .خفض
│✮ ⃟📝❯ .تغير-الاسم 
│✮ ⃟🗒️❯ .تغيرالوصف 
│✮ ⃟📸❯ .تغيرالصوره
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥🧎🏽‍♂️│الــديــن│🕋⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟🌃❯ .اذكار المساء
│✮ ⃟☀❯ .اذكار الصباح
│✮ ⃟🧎🏽‍♂️❯ .الله
│✮ ⃟📖❯ .قران
│✮ ⃟📺❯ .قران2
│✮ ⃟📿❯ .اذكار
│✮ ⃟📄❯ .اية
│✮ ⃟🕋❯ .ايه-الكرسي
│✮ ⃟📙❯ .سور
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
          ⩥⚙️│التحويلات│🧰⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟🎈❯ .ملصق
│✮ ⃟😂❯ .ميم
│✮ ⃟📝❯ .كود
│✮ ⃟🃏❯ .فضح
│✮ ⃟©️❯ .سرقه
│✮ ⃟🏞️❯ .لصورة
│✮ ⃟🎪❯ .لانمي
│✮ ⃟✨❯ .لكرتون
│✮ ⃟🎞️❯ .لفيديو
│✮ ⃟🔊❯ .لصوت
│✮ ⃟🔗❯ .تليجراف
│✮ ⃟🎭❯ .دمج
│✮ ⃟🎲❯ .نرد
│✮ ⃟🎙️❯ .انطق
│✮ ⃟🎙️❯ .انطق2
│✮ ⃟🎐❯ .مطلوب
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥🎮│العاب│🎮⩤
⟣┈┈┈┈┈┈⟢┈┈┈ـ⟣┈┈┈┈┈┈┈⟢
│✮ ⃟🎭❯ .فعاليه
│✮ ⃟❓❯ .انمي
│✮ ⃟⚽❯ .كوره
│✮ ⃟🎵❯ .تخمين
│✮ ⃟🎈❯ .العاب
│✮ ⃟⚽❯ .رياضه
│✮ ⃟❌❯ .اكس_او
│✮ ⃟📛 .امسح
│✮ ⃟🍢❯ .قرعه
│✮ ⃟🧮❯ .رياضيات
│✮ ⃟🎰❯ .رهان
│✮ ⃟💁🏻‍♂️❯ .شخصية
│✮ ⃟❓❯ .احزر
│✮ ⃟👀❯ .عين
│✮ ⃟🎈❯ .ايموجي
│✮ ⃟⚡❯ .سؤال
│✮ ⃟🎮❯ .كت
│✮ ⃟🔤❯ .احرف
│✮ ⃟🇪🇬❯ .علم
│✮ ⃟🤔❯ .خمن
│✮ ⃟🔠❯ .فكك
│✮ ⃟🔡❯ .رتب
│✮ ⃟❔❯ .اجابه
│✮ ⃟❔❯ .دين
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥🎮│الترفيه│🎮⩤
⟣┈┈┈┈┈┈⟢┈┈┈ـ⟣┈┈┈┈┈┈┈⟢
│✮ ⃟❓❯ .هل
│✮ ⃟❓❯ .لو
│✮ ⃟💡❯ .نصيحه
│✮ ⃟🤐❯ .صراحه
│✮ ⃟👑❯ .تاج
│✮ ⃟💍❯ .زواج
│✮ ⃟💔❯ .طلاق
│✮ ⃟👬❯ .صديق
│✮ ⃟👬❯ .رفيق
│✮ ⃟🙋‍♂️❯ .تحداني
│✮ ⃟🏆❯ .توب
│✮ ⃟😂❯ .ميمز
│✮ ⃟🗣❯ .مقولات
│✮ ⃟💕❯ .الحب
│✮ ⃟🎞❯ .افلام
│✮ ⃟💀❯ .فيلم-رعب
│✮ ⃟📽❯ .فيلم-اكشن
│✮ ⃟🎭❯ .فيلم-غموض
│✮ ⃟✨❯ .فيلم-دراما
│✮ ⃟🐱‍👤❯ .شخصيه
│✮ ⃟👽❯ .ذكاء
│✮ ⃟🤡❯ .غباء
│✮ ⃟☠❯ .اختراق
│✮ ⃟🤙❯ .بوست
│✮ ⃟🌟❯ .اقتباس
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥⚙️│الـأداوات│🧮⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟💬❯ .تعليق
│✮ ⃟👀❯ .شوف
│✮ ⃟🤖❯ .زورو
│✮ ⃟🌠❯ .جوده
│✮ ⃟✍🏻❯ .زخرفه
│✮ ⃟🎟️❯ .باركود
│✮ ⃟🏹❯ .ترجمة
│✮ ⃟🀄❯ .لوجو
│✮ ⃟〰️❯ .وهمي 
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
          ⩥🎙️│الـتـنزيـلات│📽️⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟📻❯ .اغنيه
│✮ ⃟📽️❯ .فيديو
│✮ ⃟🎥❯ .يوتيوب
│✮ ⃟🧸❯ .انستجرام
│✮ ⃟📱❯ .ابك-مود
│✮ ⃟📱❯ .تطبيق
│✮ ⃟📷❯ .صوره
│✮ ⃟🌅❯ .خلفيه
│✮ ⃟🎵❯ .تيك
│✮ ⃟🖼❯ .صورتيك
│✮ ⃟Ⓜ️❯ .فيس
│✮ ⃟🎧❯ .استوري
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥⚙️│الـبـحـث│📊⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟🔍❯ .فيديو
│✮ ⃟🔍❯ .ويكيبيديا
│✮ ⃟🖨️❯ .مانجا
│✮ ⃟☁❯ .الطقس
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
     ⩥🏞️│الاديـت و الـصـوره│📹⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟📹❯ .ايديت
│✮ ⃟📹❯ .ايديت2
│✮ ⃟🎴❯ .خلفيات
│✮ ⃟👩🏻‍❤️‍👨🏻❯ .تطقيم
│✮ ⃟🙋🏻‍♂️❯ .طقم-اولاد
│✮ ⃟🙋🏻‍♀️❯ .طقم-بنات
│✮ ⃟⚽❯ .كريستيانو
│✮ ⃟🐏❯ .ميسي
│✮ ⃟🦮❯ .كلب
│✮ ⃟🐈❯ .قط
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
           ⩥📌│الاعضـاء│📌⩤
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟👨🏻‍💻❯ .المطور
│✮ ⃟✴️❯ .تسجيل
│✮ ⃟📍❯ .اقتباس
│✮ ⃟🔖❯ .بروفايل
│✮ ⃟🍁❯ .الدعم
│✮ ⃟🚀❯ .بنج
│✮ ⃟👾❯ .بوت
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢`,subtitle: "مــــــيزو👑",},header: { hasMediaAttachment: true,...(await prepareWAMessageMedia({ image : { url: PLUTO } }, { upload: conn.waUploadToServer }, {quoted: m}))},
                  contextInfo: {
                      mentionedJid: [m.sender],
                      isForwarded: false,
                  },nativeFlowMessage: { buttons: [


                          {
                              name: 'single_select',
                              buttonParamsJson: JSON.stringify({
                                  title: '⌈💯╎معلومات البوت╎💯⌋',
                                  sections: [
                                      {
                                          title: 'مــرحـ🛡ـبــا بــك فـي مــ☑هــام بلوتو بـ🤖ـوت',
                                          highlight_label: 'بعبص براحتك يابرو 🤖',
                                          rows: [
                                              {
                                                  header: 'معلومات البوت',
                                                  title:'استدعاء معلومات البوت',
                                                  description: '',
                                                  id: '.معلومه'
                                              },
                                              {
                                                  header: 'معلومات عن ميزو👑',
                                                  title: 'معلومات ميزو👑',
                                                  description: 'احبك🤤💋',
                                                  id: '.مطور'
                                              },
                                              {
                                                  header: 'معلومات عن سجاد❤',
                                                  title: 'معلومات سجاد❤',
                                                  description: ' best friend ❤',
                                                  id: ''
                                              },
                                              {
                                                  header: 'معلومات عن عاهد💙',
                                                  title: 'معلومات عاهد💙',
                                                  description: 'my friend 💙',
                                                  id: ''
                                              },
                                              {
                                                
                                                  header: 'طريقه استخدام البوت',
                                                  title: 'استخدام البوت',
                                                  description: '',
                                                  id: '.',
                                             }
                                          ]
                                      }
                                  ]
                              }),
                messageParamsJson: ''
              },
              {
                  name: "quick_reply",
                      buttonParamsJson: '{"display_text":"جميع الاوامر💻","id":".اوامر"}'
                             },
                             {
                          }
                      ]
                  }
              }
          }
      }
  }, {});
}  

handler.help = ['info'];
handler.tags = ['main'];
handler.command = ['تشغيل']

export default handler;
