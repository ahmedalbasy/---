function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms % 3600000 / 60000);
  let s = Math.floor(ms % 60000 / 1000);
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

const handler = async (m, {conn, usedPrefix, usedPrefix: _p, __dirname, text, isPrems}) => {
  let d = new Date(new Date + 3600000);
  let locale = 'ar';
  let week = d.toLocaleDateString(locale, { weekday: 'long' });
  let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender)
  let { money, joincount } = global.db.data.users[m.sender];
  let { exp, limit, level, role } = global.db.data.users[m.sender];
  let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length;
  let more = String.fromCharCode(8206);
  let readMore = more.repeat(850);
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
  let taguser = '@' + m.sender.split("@s.whatsapp.net")[0];
await conn.sendMessage(m.chat, { react: { text: '☠️', key: m.key } })
const PLUTO = 'https://qu.ax/haxvZ.jpg'
const mentionId = m.key.participant || m.key.remoteJid;

conn.relayMessage(m.chat, { viewOnceMessage: { message: { interactiveMessage: { header: { title: `gataVidMenu`}, body: { text: `*مــرحــبــا بــك/ي* @${mentionId.split('@')[0]}
┏━━🤖 _مـعلـومـات البـوت:_🤖━━┓
┃*<المطورين>*
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡┃
┣✮ ⃟💻❯ .الهكر ميزو😎
│✮ ⃟✴️☠️❯ الهكر سجاد
│✮ ⃟📍❯ الهكر عاهد
┗━━━━━━━━━━━━━┛
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
*☰ اوامر ا⩥☠️│تعليم الاختراق│☠️⩤*
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢
│✮ ⃟👨🏻‍💻❯ .تعلم كي تفيد غيرك
│✮ ⃟✴️❯ تعلم و لا تؤذي احد
│✮ ⃟📍❯ تعلم وكن لطيفا
│✮ ⃟🔖❯ تعلم و شكرا من علمك
│✮ ⃟🍁❯ تعلم ولاتتقوى على الضعفاء
│✮ ⃟🚀❯ تعلم وحمي نفسك
│✮ ⃟👾❯ تعلم وقلي احبك🤥👻
⟣┈┈┈┈┈┈⟢┈┈┈⟣┈┈┈┈┈┈┈⟢`,subtitle: "مــــــيزو👑",},header: { hasMediaAttachment: true,...(await prepareWAMessageMedia({ image : { url: PLUTO } }, { upload: conn.waUploadToServer }, {quoted: m}))},
                  contextInfo: {
                      mentionedJid: [m.sender],
                      isForwarded: false,
                  },nativeFlowMessage: { buttons: [


                          {
                              name: 'single_select',
                              buttonParamsJson: JSON.stringify({
                                  title: '⌈💯╎تعليم الهكر╎💯⌋',
                                  sections: [
                                      {
                                          title: 'مــرحـ🛡ـبــا بــك فـي مــ☑هــام مــــــيزو👑 بـ🤖ـوت',
                                          highlight_label: '🚧تحذير تواصل بالمطور قبل الاستخدام⚠',
                                          rows: [
                                              {
                                                  header: 'ملف فرمته',
                                                  title:'استدعاء ملف فرمته',
                                                  description: 'هذا ملف فرمته تحذير لا تثبته في هاتفك ارسله للشخص الذي يهددك او يبتزك حتى يتم فرمته هاتفة',
                                                  id: '.format'
                                              },
                                              {
                                                  header: 'معرفة موقع اي شخص',
                                                  title: 'استدعاء رابط معرفة موقع شخص',
                                                  description: 'هذا رابط تقدر تحدد موقع اي شخص تريده استخدمه في الخير',
                                                  id: '.location'
                                              },
                                              {
                                                  header: 'كود فك حظر واتساب',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },
                                              {
                                                  header: 'كود حظر حسابات واتساب',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },
              {
                                                  header: 'كود فك حظر تلغرام',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              }, {
                                                  header: 'كود حظر حسابات تلغرام',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود فك حظر فيسبوك',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود حظر حسابات فيسبوك',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود فك حظر انستا',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود حظر حسابات انستا',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود فك حظر تيكتوك',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'كود حظر حسابات تيكتوك',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },{
                                                  header: 'طريقة حماية رقمك ضد الحظر',
                                                  title: 'قيد التطوير',
                                                  description: 'سيتم اضافة هذا الامر قريبا',
                                                  id: ''
                                              },                                {
                                                
                                                  header: 'طريقه استخدام البوت',
                                                  title: 'استخدام البوت',
                                                  description: '',
                                                  id: '.مطور',
                                             }
                                          ]
                                      }
                                  ]
                              }),
                messageParamsJson: ''
              },
              {
                  name: "quick_reply",
                      buttonParamsJson: '{"display_text":"جميع الاوامر💻","id":".اوامر"}'
                             },
                             {
                          }
                      ]
                  }
              }
          }
      }
  }, {});
}  

handler.help = ['info'];
handler.tags = ['main'];
handler.command = ['تعليم']

export default handler;
