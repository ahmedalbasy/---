let war = global.maxwarn
let handler = async (m, { conn, text, args, groupMetadata, usedPrefix, command }) => {
  let who
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
  else who = m.chat
  if (!who) throw `✳️ قم بالإشارة إلى شخص سوي له منشن أو حدد رسالته المخالفه❗\n\n📌 مثال : ${usedPrefix + command} @user`
  if (!(who in global.db.data.users)) throw `✳️ لم يتم العثور على المستخدم في قاعدة البيانات الخاصة بالبوت`
  let name = conn.getName(m.sender)
  let warn = global.db.data.users[who].warn
  if (warn < war) {
    global.db.data.users[who].warn += 1
    m.reply(
      `
⚠️ *المستخدم المحذر* ⚠️

▢ *المشرف:* ${name}
▢ *المستخدم:* @${who.split`@`[0]}
▢ *الانذار:* ${warn + 1}/${war}
▢ *بسبب:* ${text}`,
      null,
      { mentions: [who] }
    )
    m.reply(
      `
⚠️ *انذار* ⚠️
لقد تلقيت تحذيرًا من أحد المسؤولين

▢ *الانذار:* ${warn + 1}/${war} 
اذا حصلت *${war}* تحذيرات سيتم إزالتك تلقائيًا من المجموعة ❌`,
      who
    )
  } else if (warn == war) {
    global.db.data.users[who].warn = 0
    m.reply(`⛔ لقد تجاوز المستخدم *${war}* لذلك سيتم إزالة التحذيرات🚫`)
    await time(3000)
    await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
    m.reply(
      `♻️ لقد تم إزالتك من المجموعة🚯 *${groupMetadata.subject}* لأنه تم تحذيرك💯 *${war}* مرات`,
      who
    )
  }
}
handler.help = ['warn @user']
handler.tags = ['group']
handler.command = ['warn', 'انذار'، 'تحذير']
handler.group = true
handler.admin = true
handler.botAdmin = true

//export default handler

const time = async ms => {
  return new Promise(resolve => setTimeout(resolve, ms))
}
