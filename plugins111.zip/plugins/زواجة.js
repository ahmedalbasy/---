let toM = a => '@' + a.split('@')[0]
 function handler(m, { groupMetadata }) {
 let ps = groupMetadata.participants.map(v => v.id)
 let a = ps.getRandom()
 let b
 do b = ps.getRandom()
 while (b === a)
 m.reply(`${toM(a)}, *زواجة جديدة تمت* 😻🎇 \n\n ${toM(b)}, *اهم شيء 🫂 الاكل* \n\n *لا تنسو تعزمو مطوري العباسي* 👻`, null, {
 mentions: [a, b]
 })}
handler.help = ['formarpareja']
handler.tags = ['main', 'fun']
handler.command = ['زواج','زواجة']
handler.register = true
handler.group = true
export default handler