let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {

    if (!args[0]) throw `اكتب اسم التطبيق الذي تريد تنزيله. *مثال:*\n${usedPrefix + command} تصاميم`;

    let res = await fetch(`https://api.dorratz.com/v2/apk-dl?text=${args[0]}`);
    let result = await res.json();
    let { name, size, lastUpdate, icon } = result;
    let URL = result.dllink;
    let packe = result.package;

    let texto = `${rg}
   *الاسم* : ⇢ ${name} 📛
   *الحجم* : ⇢ ${size} ⚖️
   *الحزمة* : ⇢ ${packe} 📦
   *التحديث* : ⇢ ${lastUpdate} 🗓️
    
يرجى الانتظار سيتم ارسال لك طلبك قريبا ♻️..`;

    await conn.sendFile(m.chat, icon, name + '.jpg', texto, m);

    await conn.sendMessage(m.chat, { 
        document: { url: URL }, 
        mimetype: 'application/vnd.android.package-archive', 
        fileName: name + '.apk', 
        caption: '' 
    }, { quoted: m });
}

handler.command = ['apk2', 'apkdl2', 'تطبيق2'];
handler.group = true;
export default handler;
