let handler = async (m, { conn }) => {
const chat = global.db.data.chats[m.chat];
if (!chat?.savedContent || Object.keys(chat.savedContent).length === 0) return m.reply('⚠️ *لا يوجد محتوى محفوظ في هذه المجموعة.*');

let list = '📋 *قائمة المحتوى المحفوظ*\n\n';
Object.entries(chat.savedContent).forEach(([keyword, data], index) => {
list += `*${index + 1}.* 🗝️ *كلمة:* ${keyword}\n📦 *يكتب:* ${data.type}\n${data.caption ? `📝 *التسمية التوضيحية:* ${data.caption}\n` : ''}\n`;
});

await conn.sendMessage(m.chat, { text: list,mentions: Object.values(chat.savedContent).map(x => x.mentions).flat() }, { quoted: m });
};
handler.command = /^(محفوظات|listacmd|lista)$/i;
handler.group = true;
export default handler;