import { sticker } from '../lib/sticker.js'
import fetch from 'node-fetch'
import axios from 'axios';

let handler = async(m, { conn, text, args, usedPrefix, command }) => {
    if (!text) throw `${mg}اكتب النص الذي تريد تحويله الى ملصق\nمثال\n*${usedPrefix + command}* Mezo👑 DaRk\n\nاكتب النص الذي تريد تحويله الى ملصق\nمثال\n*${usedPrefix + command}* mezo dark*`
    let teks = encodeURI(text)
    if (command == 'ملصق3') {
        const data = {
            text: `${text}`
        };
        const response = await axios.post('https://salism3api.pythonanywhere.com/text2gif', data);
        const x=response.data.image;
        let stiker = await sticker(null,x,global.packname, global.author)
        conn.sendFile(m.chat, stiker, null, { asSticker: true })
    }
    if (command == 'ملصق2') {
        const data = {
            text: `${text}`,"outlineColor":"255,0,0,255", "textColor":"0,0,0,255"
        };
        const response = await axios.post('https://salism3api.pythonanywhere.com/text2img', data);
        const x=response.data.image;
        let stiker = await sticker(null,x,global.packname, global.author)
        conn.sendFile(m.chat, stiker, null, { asSticker: true })
    }
}
handler.command = handler.help = ['ملصق2', 'ملصق3']
handler.tags = ['sticker']
export default handler
