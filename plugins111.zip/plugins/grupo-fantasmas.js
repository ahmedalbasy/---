let areJidsSameUser = (await import(global.baileys)).default;

let handler = async (m, { conn, text, participants, args, command }) => {
let member = participants.map(u => u.id);
let sum = text ? parseInt(text) : member.length;
let total = 0;
let sider = [];
for (let i = 0; i < sum; i++) {
let user = member[i];
let userData = global.db.data.users[user] || {};
if ((typeof userData.mensaje === 'undefined' || userData.mensaje[m.chat] === 0) && !participants[i].isAdmin && !participants[i].isSuperAdmin) {
if (userData.whitelist !== true) {
total++;
sider.push(user);
}}}
const delay = time => new Promise(res => setTimeout(res, time));

switch (command) {
case "اشباح":
if (total == 0) return conn.reply(m.chat, `${lenguajeGB['smsAvisoAG']()}هذه المجموعة نشطة، وليس لديها أشباح👻`, m) 
m.reply(`⚠️ مراجعة الأعضاء غير نشطين ⚠️\n\nمجموعة: ${await conn.getName(m.chat)}\n*أعضاء المجموعة:* ${sum}\n*الغير نشطين:* ${total}\n\n*[ 👻 قائمة الأشباح في المجموعة 👻 ]*\n${sider.map(v => '  👉🏻 @' + v.replace(/@.+/, '')).join('\n')}\n\n*ملاحظة: قد لا يكون هذا ٪ 100 ناجحًا ، هذه رسالة للأعضاء الغير نشطين في هذه الأرقام*`, null, { mentions: sider });
break;
case "طردهم":
if (total == 0) return conn.reply(m.chat, `${lenguajeGB['smsAvisoAG']()}هذه المجموعة نشطة، وليس لديها أشباح👻`, m) ;
await m.reply(`⚠️ ازالة الغير نشطين ⚠️\n\nمجموعة: ${await conn.getName(m.chat)}\n*أعضاء المجموعة:* ${sum}\n*أعضاء غير نشطين:* ${total}\n\n[ 👻 تمت إزالة الأشباح 👻 ]\n${sider.map(v => '@' + v.replace(/@.+/, '')).join('\n')}\n\n*سيقوم البوت بحذف القائمة المذكورة بــ الأعضاء الغير نشطين  ابتداءً من 20 ثانية وكل 10 ثوانٍ يقوم بحذف رقم غير نشط*`, null, { mentions: sider });
await delay(1 * 10000);
let chat = global.db.data.chats[m.chat];
chat.welcome = false;
try {
let users = m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.id));
let kickedGhost = sider.map(v => v.id).filter(v => v !== conn.user.jid);
for (let user of users) {
if (user.endsWith('@s.whatsapp.net') && !(participants.find(v => areJidsSameUser(v.id, user)) || { admin: true }).admin) {
let res = await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
kickedGhost.concat(res);
await delay(1 * 10000);
}}} finally {
chat.welcome = true;
}
break;
}};
handler.command = /^(اشباح|طردهم)$/i;
handler.group = handler.botAdmin = handler.admin = true;
handler.fail = null;
handler.register = true;
export default handler;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

//desarrollado por https://github.com/ReyEndymion
//participa en desactivacion de despedida https://github.com/BrunoSobrino/