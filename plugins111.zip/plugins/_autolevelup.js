import { canLevelUp, xpRange } from '../lib/levelling.js'
import { levelup } from '../lib/canvas.js'
import '../plugins/_content.js'

let handler = m => m
handler.before = async function (m, { conn, usedPrefix }) {
	
if (!db.data.chats[m.chat].autolevelup) return
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let ppch = await conn.profilePictureUrl(who, 'image').catch(_ => gataMenu)
let mentionedJid = [who]
let username = conn.getName(who)
let userName = m.pushName || 'Anónimo'
	
let user = global.db.data.users[m.sender]
let chat = global.db.data.chats[m.chat]
if (m.chat === "12036334083801256@newsletter") return; 
if (m.fromMe) return
if (!chat.autolevelup) return !0

let level = user.level
let before = user.level * 1
while (canLevelUp(user.level, user.exp, global.multiplier)) 
user.level++
if (before !== user.level) {
let currentRole = Object.entries(roles).sort((a, b) => b[1] - a[1]) .find(([, minLevel]) => level + 1 >= minLevel)[0]
let nextRole = Object.entries(roles).sort((a, b) => a[1] - b[1]) .find(([, minLevel]) => level + 2 < minLevel)[0]

//if (user.role != currentRole && level >= 1) {
if (level >= 1) {
user.role = currentRole
let chtxt = `✨تهنئة لــ *${userName}*, لرتبتك الجديدة!\n\n\` رتبة جديدة::\`\n${currentRole}`
if (nextRole) {
chtxt += `\n\n> المرتبة التالية ${nextRole}, \n أحصل على *المستوى ${roles[nextRole]}*. استمر!`
}

//if (conn.user.jid === global.conn.user.jid) {	
await global.conn.sendMessage(ch.ch1, { text: chtxt, contextInfo: {
externalAdReply: {
title: "【 🔔 إشعار عام 🔔 】",
body: '😎 شخص ما حصل على رتبة جديدة!',
thumbnailUrl: ppch,
sourceUrl: accountsgb,
mediaType: 1,
showAdAttribution: false,
renderLargerThumbnail: false
}}}, { quoted: null }) 	
}
	
conn.reply(m.chat, `*╭━⊰ ${username} ⊱━დ*
*┃ ${lenguajeGB.smsAutoLv2()} ${before}*
*┃ ${lenguajeGB.smsAutoLv3()} ${user.level}*
*┃ ${lenguajeGB.smsAutoLv4()}* ${user.role}
*┃ ${lenguajeGB.smsAutoLv5()} ${new Date().toLocaleString('id-ID')}*
*╰━⊰ ${lenguajeGB.smsAutoLv1()} ⊱━━დ*

*_${lenguajeGB.smsAutoLv6()}_*`, fkontak, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
	 
let especial = ['limit', 'diamond', 'joincount', 'emerald', 'berlian', 'kyubi', 'gold', 'money', 'tiketcoin', 'stamina'].getRandom()
let especial2 = ['potion', 'aqua', 'trash', 'wood', 'rock', 'batu', 'string', 'iron', 'coal', 'botol', 'kaleng', 'kardus'].getRandom()
let especial3 = ['eleksirb', 'emasbatang', 'emasbiasa', 'rubah', 'sampah', 'serigala', 'kayu', 'sword', 'umpan', 'healtmonster', 'emas', 'pancingan', 'pancing'].getRandom()
let especial4 = ['common', 'uncoommon', 'mythic', 'pet', 'gardenboxs', 'legendary'].getRandom()

let especialCant = Math.floor(Math.random() * (9 - 6 + 1)) + 6 // Intervalo: 6 a 9
let especialCant2 = Math.floor(Math.random() * (10 - 6 + 1)) + 6 // Intervalo: 6 a 10
let especialCant3 = Math.floor(Math.random() * (10 - 6 + 1)) + 6 // Intervalo: 6 a 10
let especialCant4 = Math.floor(Math.random() * (3 - 2 + 1)) + 2 // Intervalo: 2 a 3

let normal = ['potion', 'aqua', 'trash', 'wood', 'rock', 'batu', 'string', 'iron', 'coal', 'botol', 'kaleng', 'kardus'].getRandom()
let normal2 = ['petFood', 'makanancentaur', 'makanangriffin', 'makanankyubi', 'makanannaga', 'makananpet', 'makananphonix'  ].getRandom()
let normal3 = ['anggur', 'apel', 'jeruk', 'mangga', 'pisang'].getRandom()

let normalCant = [1, 3, 3, 3, 4, 4, 2, 2, 4, 4, 4, 4, 1].getRandom() 
let normalCant2 = [1, 3, 2, 2, 4, 4, 2, 2, 4, 4, 5, 5, 1].getRandom() 
let normalCant3 = [1, 3, 3, 3, 4, 4, 2, 2, 4, 4, 4, 4, 1].getRandom() 

if (level >= 1) {
let chtxt = `👤 *المستخدم:* ${userName}\n🆙 *المستوى السابق* ${before}\n🆕 *المستوى الحالي:* ${level + 1}\n👾 *رتبتك:* ${user.role}\n🐈 *بــوت:* ${gt}${(level + 1) % 5 === 0 ? `\n\n💰 *مكافأة للوصول إلى المستوى ${level + 1}:*
🎁 *هدية:* \`X${Math.floor(((level + 1) - 5) / 10) + 1}\`
- *${especialCant * (Math.floor(((level + 1) - 5) / 10) + 1)} ${global.rpgshop.emoticon(especial)}*
- *${especialCant2 * (Math.floor(((level + 1) - 5) / 10) + 1)} ${global.rpgshop.emoticon(especial2)}*
- *${especialCant3 * (Math.floor(((level + 1) - 5) / 10) + 1)} ${global.rpgshop.emoticon(especial3)}*
- *${especialCant4 * (Math.floor(((level + 1) - 5) / 10) + 1)} ${global.rpgshop.emoticon(especial4)}*

> 👀 المكافأة التالية في *المستوى ${level + 6}*` : ''}`.trim()
await global.conn.sendMessage(ch.ch1, { text: chtxt, contextInfo: {
externalAdReply: {
title: "【 🔔 اشعار عام 🔔 】",
body: '⭐شخص ما وصل إلى مستوى',
thumbnailUrl: ppch,
sourceUrl: accountsgb,
mediaType: 1,
showAdAttribution: false,
renderLargerThumbnail: false
}}}, { quoted: null }) 
}

if (user.level == 5){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 5!!* 🏆
𓃠 *${especialCant * 1} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 1} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 1} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 1} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}}) 
user[especial] += especialCant * 1
user[especial2] += especialCant2 * 1
user[especial3] += especialCant3 * 1
user[especial4] += especialCant4 * 1
  
}else if (user.level == 10){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 10!!* 🏆
𓃠 *${especialCant * 1} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 1} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 1} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 1} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}}) 
user[especial] += especialCant * 1
user[especial2] += especialCant2 * 1
user[especial3] += especialCant3 * 1
user[especial4] += especialCant4 * 1
  
}else if (user.level == 15){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 15!!* 🏆
𓃠 *${especialCant * 2} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 2} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 2} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 2} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}}) 
user[especial] += especialCant * 2
user[especial2] += especialCant2 * 2
user[especial3] += especialCant3 * 2
user[especial4] += especialCant4 * 2
  
}else if (user.level == 20){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 20!!* 🏆
𓃠 *${especialCant * 2} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 2} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 2} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 2} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb}}}) 
user[especial] += especialCant * 2
user[especial2] += especialCant2 * 2
user[especial3] += especialCant3 * 2
user[especial4] += especialCant4 * 2
  
}else if (user.level == 25){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 25!!* 🏆
𓃠 *${especialCant * 3} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 3} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 3} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 3} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 3
user[especial2] += especialCant2 * 3
user[especial3] += especialCant3 * 3
user[especial4] += especialCant4 * 3
	
}else if (user.level == 30){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 30!!* 🏆
𓃠 *${especialCant * 3} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 3} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 3} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 3} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 3
user[especial2] += especialCant2 * 3
user[especial3] += especialCant3 * 3
user[especial4] += especialCant4 * 3
	
}else if (user.level == 35){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 35!!* 🏆
𓃠 *${especialCant * 4} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 4} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 4} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 4} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 4
user[especial2] += especialCant2 * 4
user[especial3] += especialCant3 * 4
user[especial4] += especialCant4 * 4
	
}else if (user.level == 40){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 40!!* 🏆
𓃠 *${especialCant * 4} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 4} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 4} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 4} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 4
user[especial2] += especialCant2 * 4
user[especial3] += especialCant3 * 4
user[especial4] += especialCant4 * 4
	
}else if (user.level == 45){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 45!!* 🏆
𓃠 *${especialCant * 5} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 5} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 5} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 5} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 5
user[especial2] += especialCant2 * 5
user[especial3] += especialCant3 * 5
user[especial4] += especialCant4 * 5
	
}else if (user.level == 50){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 50!!* 🏆
𓃠 *${especialCant * 5} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 5} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 5} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 5} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 5
user[especial2] += especialCant2 * 5
user[especial3] += especialCant3 * 5
user[especial4] += especialCant4 * 5
	
}else if (user.level == 55){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 55!!* 🏆
𓃠 *${especialCant * 6} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 6} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 6} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 6} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 6
user[especial2] += especialCant2 * 6
user[especial3] += especialCant3 * 6
user[especial4] += especialCant4 * 6
	
}else if (user.level == 60){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 60!!* 🏆
𓃠 *${especialCant * 6} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 6} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 6} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 6} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 6
user[especial2] += especialCant2 * 6
user[especial3] += especialCant3 * 6
user[especial4] += especialCant4 * 6
	
}else if (user.level == 65){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 65!!* 🏆
𓃠 *${especialCant * 7} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 7} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 7} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 7} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 7
user[especial2] += especialCant2 * 7
user[especial3] += especialCant3 * 7
user[especial4] += especialCant4 * 7
	
}else if (user.level == 70){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 70!!* 🏆
𓃠 *${especialCant * 7} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 7} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 7} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 7} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 7
user[especial2] += especialCant2 * 7
user[especial3] += especialCant3 * 7
user[especial4] += especialCant4 * 7
	
}else if (user.level == 75){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 75!!* 🏆
𓃠 *${especialCant * 8} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 8} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 8} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 8} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 8
user[especial2] += especialCant2 * 8
user[especial3] += especialCant3 * 8
user[especial4] += especialCant4 * 8
	
}else if (user.level == 80){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 80!!* 🏆
𓃠 *${especialCant * 8} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 8} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 8} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 8} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 8
user[especial2] += especialCant2 * 8
user[especial3] += especialCant3 * 8
user[especial4] += especialCant4 * 8
	
}else if (user.level == 85){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 85!!* 🏆
𓃠 *${especialCant * 9} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 9} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 9} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 9} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb}}})
user[especial] += especialCant * 9
user[especial2] += especialCant2 * 9
user[especial3] += especialCant3 * 9
user[especial4] += especialCant4 * 9
	
}else if (user.level == 90){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 90!!* 🏆
𓃠 *${especialCant * 9} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 9} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 9} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 9} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 9
user[especial2] += especialCant2 * 9
user[especial3] += especialCant3 * 9
user[especial4] += especialCant4 * 9
	
}else if (user.level == 95){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 95!!* 🏆
𓃠 *${especialCant * 10} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 10} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 10} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 10} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 10
user[especial2] += especialCant2 * 10
user[especial3] += especialCant3 * 10
user[especial4] += especialCant4 * 10
	
}else if (user.level == 100){
conn.reply(m.chat, `*${lenguajeGB.smsAutoLv7()} 100!!* 🏆
𓃠 *${especialCant * 10} ${global.rpgshop.emoticon(especial)}*
𓃠 *${especialCant2 * 10} ${global.rpgshop.emoticon(especial2)}*
𓃠 *${especialCant3 * 10} ${global.rpgshop.emoticon(especial3)}*
𓃠 *${especialCant4 * 10} ${global.rpgshop.emoticon(especial4)}*`, m, {contextInfo: {externalAdReply :{ mediaUrl: null, mediaType: 1, description: null, title: gt, body: ' 😻 بــــوت مــــــيزو👑 ', previewType: 0, thumbnail: gataImg, sourceUrl: accountsgb }}})
user[especial] += especialCant * 10
user[especial2] += especialCant2 * 10
user[especial3] += especialCant3 * 10
user[especial4] += especialCant4 * 10
	
}else{	
	
}
	 
}}		
export default handler

global.roles = {
// Nivel 0-9: Principiantes
'🌱 *مغامر - مبتدئ 1*': 0,
'🌱 *مغامر - مبتدئ 2*': 2,
'🌱 *مغامر - مبتدئ 3*': 4,
'🌱 *مغامر - مبتدئ 4*': 6,
'🌱 *مغامر - مبتدئ 5*': 8,

// Nivel 10-19: Aprendices
'🛠️ *تلميذ V*': 10,
'🛠️ *تلميذ IV*': 12,
'🛠️ *تلميذ III*': 14,
'🛠️ *تلميذ II*': 16,
'🛠️ *تلميذ I*': 18,

// Nivel 20-29: Exploradores
'⚔️ *مستكشف الوادي V*': 20,
'⚔️ *مستكشف الوادي IV*': 22,
'⚔️ *مستكشف الوادي III*': 24,
'⚔️ *مستكشف الوادي II*': 26,
'⚔️ *مستكشف الوادي I*': 28,

// Nivel 30-39: Guerreros
'🏹 *محارب V*': 30,
'🏹 *محارب IV*': 32,
'🏹 *محارب III*': 34,
'🏹 *محارب II*': 36,
'🏹 *محارب I*': 38,

// Nivel 40-49: Guardianes
'🛡️ *حارس الغابات V*': 40,
'🛡️ *حارس الغابات IV*': 42,
'🛡️ *حارس الغابات III*': 44,
'🛡️ *حارس الغابات II*': 46,
'🛡️ *حارس الغابات I*': 48,

// Nivel 50-59: Magos
'🔮 *دكتور V*': 50,
'🔮 *دكتور IV*': 52,
'🔮 *دكتور III*': 54,
'🔮 *دكتور II*': 56,
'🔮 *دكتور I*': 58,

// Nivel 60-79: Élite
'🏅 *البطل الذهبي V*': 60,
'🏅 *البطل الذهبي IV*': 62,
'🏅 *البطل الذهبي III*': 64,
'🏅 *البطل الذهبي II*': 66,
'🏅 *البطل الذهبي I*': 68,
'💎 *الالماسي V*': 70,
'💎 *الالماسي IV*': 72,
'💎 *الالماسي III*': 74,
'💎 *الالماسي II*': 76,
'💎 *الالماسي I*': 78,

// Nivel 80-99: Maestros
'🌌 *معلم النجوم V*': 80,
'🌌 *معلم النجوم IV*': 85,
'🌌 *معلم النجوم III*': 90,
'🌌 *معلم النجوم II*': 95,
'🌌 *معلم النجوم I*': 99,

// Nivel 100-149: Legendarios
'🌀 *أسطورة أورورا V*': 100,
'🌀 *أسطورة أورورا IV*': 110,
'🌀 *أسطورة أورورا III*': 120,
'🌀 *أسطورة أورورا II*': 130,
'🌀 *أسطورة أورورا I*': 140,

// Nivel 150-199: Reyes/Reinas
'👑 *ملك/ملكة الكون V*': 150,
'👑 *ملك/ملكة الكون IV*': 160,
'👑 *ملك/ملكة الكون III*': 170,
'👑 *ملك/ملكة الكون II*': 180,
'👑 *ملك/ملكة الكون I*': 199,

// Nivel 200-299: Campeones
'🚀 *بطل المجرات V*': 200,
'🚀 *بطل المجرات IV*': 225,
'🚀 *بطل المجرات III*': 250,
'🚀 *بطل المجرات II*': 275,
'🚀 *بطل المجرات I*': 299,

// Nivel 300-399: Luz superior
'✨ *ضوء نور الكون V*': 300,
'✨ *ضوء نور الكون IV*': 325,
'✨ *ضوء نور الكون III*': 350,
'✨ *ضوء نور الكون II*': 375,
'✨ *ضوء نور الكون I*': 399,

// Nivel 400-499: Tejedor supremo
'🪐 *المذنب الكونيا V*': 400,
'🪐 *المذنب الكوني IV*': 425,
'🪐 *المذنب الكوني III*': 450,
'🪐 *المذنب الكوني II*': 475,
'🪐 *المذنب الكوني I*': 499,

// Nivel 500-599: Reflejo supremo
'🪞 *Reflejo Supremo del Destino V*': 500,
'🪞 *Reflejo Supremo del Destino IV*': 525,
'🪞 *Reflejo Supremo del Destino III*': 550,
'🪞 *Reflejo Supremo del Destino II*': 575,
'🪞 *Reflejo Supremo del Destino I*': 599,

// Nivel 600-699: Metamorfosis
'🦋 *التحول النجمي V*': 600,
'🦋 *التحول النجمي IV*': 625,
'🦋 *التحول النجمي III*': 650,
'🦋 *التحول النجمي II*': 675,
'🦋 *التحول النجمي I*': 699,

// Nivel 700-799: Runas del Destino
'💠 *حاكم المجره V*': 700,
'💠 *حاكم المجره IV*': 725,
'💠 *حاكم المجره III*': 750,
'💠 *حاكم المجره II*': 775,
'💠 *حاكم المجره I*': 799,

// Nivel 800-899: Mente brillante
'🧠 *العقل العالمي V*': 800,
'🧠 *العقل العالمي IV*': 825,
'🧠 *العقل العالمي III*': 850,
'🧠 *العقل العالمي II*': 875,
'🧠 *العقل العالمي I*': 899,

// Nivel 900-999: Viajero(a)
'🛸 *مسافر عبر الزمن V*': 900,
'🛸 *مسافر عبر الزمن IV*': 925,
'🛸 *مسافر عبر الزمن III*': 950,
'🛸 *مسافر عبر الزمن II*': 975,
'🛸 *مسافر عبر الزمن I*': 999,

// Nivel 300+: Inmortales
'🔥 *البطل الخالد V*': 1000,
'🔥 *البطل الخالد IV*': 2000,
'🔥 *البطل الخالد III*': 3000,
'🔥 *البطل الخالد II*': 4000,
'🔥 *البطل الخالد I*': 5000,
'👑🌌 *الملك الخارق* ⚡': 10000,
}
