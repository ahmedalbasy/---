let toM = a => '@' + a.split('@')[0]
 function handler(m, { groupMetadata }) {
 let ps = groupMetadata.participants.map(v => v.id)
 let a = ps.getRandom()
let b
 do b = ps.getRandom()
 while (b === a)
 m.reply(`*${toM(a)}, للاسف سوف تفترقون😔💔*
 *${toM(b)},* \n\n *انها النهاية 💔* \n\n *اذا بدكم ترجعو لبعض ضروري يكون ميزو محلل* 😻👻`, null, {
 mentions: [a, b]
})}
handler.help = ['formarpareja']
handler.tags = ['main', 'fun']
handler.command = ['الطلاق','طلاق']
handler.register = true
 handler.group = true
export default handler