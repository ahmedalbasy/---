let handler = async (m, { conn, usedPrefix, command, args: [event], text }) => {
if (!event) return await m.reply(`${mid.smsMalused7}

${usedPrefix + command} welcome @user
${usedPrefix + command} bye @user
${usedPrefix + command} promote @user
${usedPrefix + command} demote @user`) 
/*conn.sendButton(m.chat, `${mid.smsMalused7}

${usedPrefix + command} welcome @user
${usedPrefix + command} bye @user
${usedPrefix + command} promote @user
${usedPrefix + command} demote @user`.trim(), wm, null, [['WELCOME', '#simulate welcome'], ['BYE', '#simulate bye']])*/
let mentions = text.replace(event, '').trimStart()
let who = mentions ? conn.parseMention(mentions) : []
let part = who.length ? who : [m.sender]
let act = false
m.reply(`*محاكاه امر ${event}...*`)
switch (event.toLowerCase()) {
case 'add':
case 'رحب':
case 'ترحيب':
case 'bienvenida':       
act = 'add'
break
case 'مغادرة':
case 'معادره':
case 'leave':
case 'remove':
case 'sacar':
act = 'remove'
break
case 'ادمن':
case 'ترقية':
case 'ترقيه':
act = 'promote'
break
case 'اعفاء':
case 'نزله من الادمن':
case 'quitarpoder':
act = 'demote'
break
default:
throw 'خطأ، أدخل خيارًا صالحآ'
}
if (act) return conn.participantsUpdate({
id: m.chat,
participants: part,
action: act
})}
handler.help = ['simulate <event> [@mention]','simular <event>'] 
handler.tags = ['owner']
handler.command = /^محاكاة|محاكاه$/i
handler.group = true
export default handler
