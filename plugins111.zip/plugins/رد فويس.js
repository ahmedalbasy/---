let handler = m => m;
handler.all = async function (m) {
  let chat = global.db.data.chats[m.chat];

  if (/^احا|احااا$/i.test(m.text)) {
    let vn =  'https://files.catbox.moe/qsrmd9.m4a' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
if (/^استخدام$/i.test(m.text)) {

   await conn.sendMessage(m.chat, {text: '`استخدم كلمة 👈 بوت 👉 قبل التحدث معي`'}, {quoted: m});

    }
if (/^ضحكة ميزو|ضحكه ميزو$/i.test(m.text)) {
    let vn =  'https://qu.ax/QaRWx.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
if (/^بووت$/i.test(m.text)) {
    let vn =  'https://qu.ax/HLwRg.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
if (/^بوته|بوتة$/i.test(m.text)) {
    let vn =  'https://qu.ax/KDuek.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
if (/^اوامر$/i.test(m.text)) {
   await conn.sendMessage(m.chat, {text: '⌛ انا بوت ميزو🤖 لحمايه القروبات و التسليه و خدمات كثيرة  لاستخدام البوت ارسل  `اوامر` ملاحظة ⚠️ اكتب نقطة قبل اي امر⚡'}, {quoted: m});
    }
if (/^ارحب|حيا$/i.test(m.text)) {
    let vn =  'https://qu.ax/RQOw' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 
if (/^قيق|^بيق|^قييق|^بقيق|بق$/i.test(m.text)) {
    let vn =  'https://qu.ax/BbARa.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 
if (/^اسكت|ا^وص|^اصه|^هوس|^سكت|ا^وس|^صه|^اصة|^صة|^🤫🤫$/i.test(m.text)) {
    let vn =  'https://qu.ax/EJizM.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 
if (/^هلا|^هاي|هااي$/i.test(m.text)) {
    let vn =  'https://qu.ax/WTXLE.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 
  
  if (/^الجن|جن$/i.test(m.text)) {
    let vn =  'https://qu.ax/RQOw' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
 if (/^🙂🙂$|انصدمت$/i.test(m.text)) {
    let vn =  'https://files.catbox.moe/bqtufo.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
 }
  if (/^سبحانه$/i.test(m.text)) {
    let vn =  'https://qu.ax/nGFt.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^علاوي$/i.test(m.text)) {
    let vn =  'https://qu.ax/vXcL.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^انقلع$/i.test(m.text)) {
    let vn =  'https://qu.ax/vmpQz.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 

if (/^زواجه|^زواج|^تزوج|^زواجة|زوجوني$/i.test(m.text)) {
    let vn =  'https://qu.ax/APjUz.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  } 

if (/^جعلك|مغص$/i.test(m.text)) {
    let vn =  'https://qu.ax/jeZjM.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }

if (/^تف$|^تفو$|^تفوو$|^تف تف$|^تفووو$/i.test(m.text)) {
    let vn =  'https://qu.ax/dSVgk.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }

if (/^ارحب|حيا$/i.test(m.text)) {
    let vn =  'https://qu.ax/YsDJw.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^دانس$/i.test(m.text)) {
    let vn =  'https://qu.ax/NDrj.m4a' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype: 'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^ههههههههههه|😂😂😂😂😂😂😂😂|ضحك$/i.test(m.text)) {
    let vn =  'https://qu.ax/PFyy.wav' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  
if (/^ابكي|^🥲🥲$|😭😭$/i.test(m.text)) {
    let vn =  'https://qu.ax/cGZXh.mp3' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }

  if (/^بضاني$/i.test(m.text)) {
    let vn = 'https://qu.ax/oOd';
    conn.sendPresenceUpdate('recording', m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype: 'audio/mpeg', fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^بقولك$/i.test(m.text)) {
    let vn = 'https://file.io/tMm6PadRdSaj';
    conn.sendPresenceUpdate('recording', m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype: 'audio/mpeg', fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^نو ريب$/i.test(m.text)) {
    let vn =  'https://qu.ax/pSra' ;
    conn.sendPresenceUpdate( 'recording' , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:  'audio/mpeg' , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^انا الادمن|هات رول|رول$/i.test(m.text)) {
    let vn =   'https://qu.ax/pEbX'  ;
    conn.sendPresenceUpdate(  'recording'  , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:   'audio/mpeg'  , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
if (/^منور|منورة|منوره$/i.test(m.text)) {
    let vn =     'https://files.catbox.moe/1auhni.webm'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
}
  if (/^راب فشيخ$/i.test(m.text)) {
    let vn =    'https://qu.ax/MGGw'   ;
    conn.sendPresenceUpdate(   'recording'   , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:    'audio/mpeg'   , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^دساااوقي$/i.test(m.text)) {
    let vn =     'https://qu.ax/WOgR'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^سامو عليكو|^السلام|^سلام|السلام عليكم|سمو عليكو/i.test(m.text)) {
    let vn =     'https://qu.ax/LASb.wav'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^الغزاله$/i.test(m.text)) {
    let vn =     'https://qu.ax/nlVt'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^نا هنام|^نام|بنام$/i.test(m.text)) {
    let vn =     'https://qu.ax/OJjK'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  if (/^ربنا يسمحك$/i.test(m.text)) {
    let vn =     'https://qu.ax/cZJu'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }
  
  if (/^خخ|خخخ|خخخخ|خخخخخخخ|خخخخخخ$/i.test(m.text)) {
    let vn =     'https://qu.ax/YYHr'    ;
    conn.sendPresenceUpdate(    'recording'    , m.chat);
    conn.sendMessage(m.chat, { audio: { url: vn }, ptt: true, mimetype:     'audio/mpeg'    , fileName: `mezo_bot_2025.opp` }, { quoted: m });
  }


  return !0;
};
handler.private = true;
export default handler;