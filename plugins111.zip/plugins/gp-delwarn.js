let handler = async (m, { conn, args, groupMetadata }) => {
  let who
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
  else who = m.chat
  if (!who) throw `✳️ قم بالإشارة إلى شخص سوي له منشن أو حدد رسالته المخالفه❗`
  if (!(who in global.db.data.users)) throw `✳️ لم يتم العثور على المستخدم في قاعدة البيانات الخاصة بي`
  let warn = global.db.data.users[who].warn
  if (warn > 0) {
    global.db.data.users[who].warn -= 1
    m.reply(`⚠️ *حذف الانذار*
         
▢ تحذير🚨: *-1*
▢ اجمالي التحذيرات 🚧: *${warn - 1}*`)
    m.reply(`✳️ لقد قام أحد المشرفين بازالة انذار،〽️ والآن لديك *${warn - 1}*`, who)
  } else if (warn == 0) {
    m.reply('✳️ المستخدم ليس لديه اي تحذير😻')
  }
}
handler.help = ['delwarn @user']
handler.tags = ['group']
handler.command = ['delwarn', 'unwarn', 'تراجع']
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler
